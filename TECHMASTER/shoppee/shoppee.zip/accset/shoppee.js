var test = document.querySelector('.category__heading');

setInterval(function() {
    test.classList.toggle('category__heading-red');
}, 400)

alert('Xin chào');